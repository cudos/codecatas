/*
 *  randomtree.c - demonstrates an unbalanced binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <randomtree.h>

int main(void)
{
	MBrandomtree * tree;
	char * elements[] = {"A", "B", "C", "D", "E", "F", "G"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	const char * data;
	MBiterator *iterator;

	tree = MBrandomtree_create((MBcmpfn)strcmp);

    for (i = 0; i < n; i++) {
		MBrandomtree_add(tree, elements[i]);
	}
	MBrandomtree_for_each(tree, (MBforfn)puts);
	printf("Size is %d\n", MBrandomtree_get_count(tree));
	for (i = 0; i < n; i++) {
		data = MBrandomtree_find(tree, elements[i]);
		if (data) {
			printf("Found %s\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[i]);
		}
		printf("Index is %d\n", MBrandomtree_find_index(tree, elements[i]));
	}
	printf("%d\n", tree->root->key);
	iterator = MBrandomtree_iterator(tree);
	printf("Tree contains:\n");
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
	for (i = 0; i < n; i++) {
		printf("Removing %s\n", elements[i]);
		data = MBrandomtree_remove(tree, elements[i]);
		if (data) {
			printf("%s successfully removed\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[i]);
		}
		printf("Size is now %d\n", MBrandomtree_get_count(tree));
		printf("Check keys: %d\n", MBrandomtree_check_keys(tree));
	}
	
	MBrandomtree_delete(tree);

	return 0;
}
