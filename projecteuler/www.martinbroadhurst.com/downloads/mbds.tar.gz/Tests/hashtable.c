/*
 *  hashtable.c - demonstrates a hash table
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <hashtable.h>
#include <linkedlist.h>

#include "CuTest.h"

/* The SDBM hash */
unsigned int myhashfunc(const char * str)
{
	unsigned int hash = 0;
	int c;

	while ((c = *str++)) {
		hash = c + (hash << 6) + (hash << 16) - hash;
	}

	return hash;
}

unsigned int count;

void myforfn(void *data)
{
	count++;
}

void test_hashtable(CuTest *tc)
{
	MBhashtable * table;
	MBlinkedlist * list;
	MBlistnode * node;
	const unsigned int n = 100;
	unsigned int i;
	char buf[64];
	MBiterator *iterator;
	char *data;

	table = MBhashtable_create(4, (MBhashfn)myhashfunc, (MBcmpfn)strcmp);
	CuAssertPtrNotNull(tc, table);
	list = MBlinkedlist_create();
	CuAssertPtrNotNull(tc, list);

	i = 0;
    while (i < n) {
		void *copy;
		sprintf(buf, "%d", rand());	
		copy = strdup(buf); 	
		data = MBhashtable_add(table, copy);
		if (data == NULL) {
			MBlinkedlist_add_tail(list, copy);
			i++;
			CuAssertIntEquals(tc, i, MBhashtable_find_count(table));
		}
		else {
			/* Duplicate entry */
			void *existing = MBhashtable_find(table, buf);
			CuAssertPtrNotNull(tc, existing);
			CuAssertStrEquals(tc, buf, existing);
			free(data);
		}
	}
	CuAssertIntEquals(tc, MBhashtable_get_count(table), MBlinkedlist_get_count(list));
	for (node = list->head; node != NULL; node = node->next) {
		data = MBhashtable_find(table, node->data);
		CuAssertPtrNotNull(tc, data);
	}
	count = 0;
	MBhashtable_for_each(table, myforfn);
	CuAssertIntEquals(tc, n, count);
	iterator = MBhashtable_iterator(table);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, n, count);
	MBiterator_delete(iterator);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBhashtable_remove(table, node->data);
		CuAssertPtrNotNull(tc, data);
		free(data);
		data = MBhashtable_find(table, node->data);
		CuAssertPtrNull(tc, data);
		count--;
		CuAssertIntEquals(tc, MBhashtable_get_count(table), count);
	}
	
	MBlinkedlist_delete(list);
	MBhashtable_delete(table);
}

CuSuite* hashtable_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_hashtable);
	return suite;
}
