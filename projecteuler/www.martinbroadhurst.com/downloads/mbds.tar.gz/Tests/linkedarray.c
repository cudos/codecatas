/*
 *  linkedarray.c - demonstrates a linkedarray
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <linkedarray.h>

#include "CuTest.h"

typedef void (*addfn)(MBlinkedarray*, void*);
typedef void*(*removefn)(MBlinkedarray*);

void test_linkedarray_add_remove(MBlinkedarray *linkedarray, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBlinkedarray_get_count(linkedarray), i);
		addfn(linkedarray, elements[i]);
	}
	CuAssertIntEquals(tc, MBlinkedarray_get_count(linkedarray), n);
	/*MBlinkedarray_for_each(linkedarray, (MBforfn)puts);*/
	it = MBlinkedarray_iterator(linkedarray);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(linkedarray);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBlinkedarray_get_count(linkedarray));
}

void test_linkedarray(CuTest *tc)
{
	addfn addfns[] = { MBlinkedarray_add_tail, MBlinkedarray_add_head };
	removefn removefns[] = { MBlinkedarray_remove_tail, MBlinkedarray_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBlinkedarray * linkedarray = MBlinkedarray_create();
	CuAssertPtrNotNull(tc, linkedarray);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_linkedarray_add_remove(linkedarray, addfns[a], removefns[r], tc);
		}
	}
	MBlinkedarray_delete(linkedarray);
}

CuSuite* linkedarray_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_linkedarray);
	return suite;
}
