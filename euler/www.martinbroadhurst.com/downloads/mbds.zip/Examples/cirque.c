/*
 *  cirque.c - demonstrates a circular queue
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <cirque.h>

int main(void)
{
	MBcirque * cirque;
	char buf[16];
	unsigned int f;
	const unsigned int max = 30;
	const unsigned int size = 10;
	const unsigned int limit = size * 2;
	MBiterator * iterator;
	const char * data;
	unsigned int count = 0;

	cirque = MBcirque_create(size);
	for (f = 0; f < max; f++) {
		sprintf(buf, "Item %d", f);
		if (f >= limit) {
			/* Start removing at limit to show the cirque doesn't keep growing */
			char *data = MBcirque_remove(cirque);
			printf("Removed %s\n", data);
			free(data);
			count--;
		}
		printf("Inserting %s\n", buf);
		MBcirque_insert(cirque, strdup(buf));
		count++;
		printf("Count is %d (should be %d)\n", MBcirque_get_count(cirque), count);
	}
	/*MBcirque_for_each(cirque, (MBforfn)puts);*/
	iterator = MBcirque_iterator(cirque);
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
	printf("Size is %d (should be %d)\n", cirque->size, limit);
	MBcirque_for_each(cirque, free);
	MBcirque_delete(cirque);

	return 0;
}
