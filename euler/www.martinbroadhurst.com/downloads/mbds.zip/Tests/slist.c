/*
 *  slist.c - demonstrates a slist
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <slist.h>

#include "CuTest.h"

typedef void (*addfn)(MBslist*, void*);
typedef void*(*removefn)(MBslist*);

void test_slist_add_remove(MBslist *slist, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBslist_get_count(slist), i);
		addfn(slist, elements[i]);
	}
	CuAssertIntEquals(tc, MBslist_get_count(slist), n);
	/*MBslist_for_each(slist, (MBforfn)puts);*/
	it = MBslist_iterator(slist);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(slist);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBslist_get_count(slist));
}

void test_slist(CuTest *tc)
{
	addfn addfns[] = { MBslist_add_tail, MBslist_add_head };
	removefn removefns[] = { MBslist_remove_tail, MBslist_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBslist * slist = MBslist_create();
	CuAssertPtrNotNull(tc, slist);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_slist_add_remove(slist, addfns[a], removefns[r], tc);
		}
	}
	MBslist_delete(slist);
}

CuSuite* slist_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_slist);
	return suite;
}
