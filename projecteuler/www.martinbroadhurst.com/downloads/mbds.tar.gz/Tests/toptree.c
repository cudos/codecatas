/*
 *  toptree.c - demonstrates an unbalanced binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <string.h>
#include <stdlib.h>

#include <toptree.h>
#include <linkedlist.h>

#include "CuTest.h"

void test_toptree(CuTest *tc)
{
	MBtoptree * tree;
	MBlinkedlist * list;
	MBlistnode * node;
	const unsigned int n = 100;
	unsigned int i;
	char buf[64];
	MBiterator *iterator;
	char *data;
	unsigned int count;

	tree = MBtoptree_create((MBcmpfn)strcmp);
	CuAssertPtrNotNull(tc, tree);
	list = MBlinkedlist_create();
	CuAssertPtrNotNull(tc, list);

	i = 0;
    while (i < n) {
		void *copy;
		sprintf(buf, "%d", rand());	
		copy = strdup(buf); 	
		data = MBtoptree_add(tree, copy);
		if (data == NULL) {
			MBlinkedlist_add_tail(list, copy);
			i++;
		}
		else {
			/* Duplicate entry */
			free(data);
		}
	}
	CuAssertIntEquals(tc, MBtoptree_get_count(tree), n);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBtoptree_find(tree, node->data);
		CuAssertPtrNotNull(tc, data);
		/* Check that the found item is now at the top of the tree */
		CuAssertStrEquals(tc, data, tree->root->data);
	}
	iterator = MBtoptree_iterator(tree);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(iterator);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBtoptree_remove(tree, node->data);
		CuAssertPtrNotNull(tc, data);
		free(data);
		count--;
		CuAssertIntEquals(tc, MBtoptree_get_count(tree), count);
	}
	
	MBlinkedlist_delete(list);
	MBtoptree_delete(tree);
}

CuSuite* toptree_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_toptree);
	return suite;
}
