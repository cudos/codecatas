/*
 *  queue.c - demonstrates a queue
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <queue.h>

#include "CuTest.h"

void test_queue(CuTest *tc)
{
	MBqueue *queue;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBiterator *iterator;
	const char *data;
	unsigned int count;

	queue = MBqueue_create();
	CuAssertPtrNotNull(tc, queue);
	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, i, MBqueue_get_count(queue));
		MBqueue_add(queue, elements[i]);
	}
	CuAssertIntEquals(tc, n, MBqueue_get_count(queue));
	/*MBqueue_for_each(queue, (MBforfn)puts);*/
	iterator = MBqueue_iterator(queue);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		CuAssertStrEquals(tc, elements[count], data);
		count++;
	}
	CuAssertIntEquals(tc, n, count);
	MBiterator_delete(iterator);

	for (i = 0; i < n; i++) {
		data = MBqueue_peek(queue);
		CuAssertStrEquals(tc, elements[i], data);
		data = MBqueue_remove(queue);
		CuAssertStrEquals(tc, elements[i], data);
		CuAssertIntEquals(tc, n - (i + 1), MBqueue_get_count(queue)); 
	}
	CuAssertPtrNull(tc, MBqueue_peek(queue));
	MBqueue_delete(queue);
}

CuSuite* queue_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_queue);
	return suite;
}
