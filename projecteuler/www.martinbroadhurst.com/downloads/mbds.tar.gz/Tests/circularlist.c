/*
 *  circularlist.c - demonstrates a circularlist
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <circularlist.h>

#include "CuTest.h"

typedef void (*addfn)(MBcircularlist*, void*);
typedef void*(*removefn)(MBcircularlist*);

void test_circularlist_add_remove(MBcircularlist *circularlist, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBcircularlist_get_count(circularlist), i);
		addfn(circularlist, elements[i]);
	}
	CuAssertIntEquals(tc, MBcircularlist_get_count(circularlist), n);
	/*MBcircularlist_for_each(circularlist, (MBforfn)puts);*/
	it = MBcircularlist_iterator(circularlist);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(circularlist);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBcircularlist_get_count(circularlist));
}

void test_circularlist(CuTest *tc)
{
	addfn addfns[] = { MBcircularlist_add_tail, MBcircularlist_add_head };
	removefn removefns[] = { MBcircularlist_remove_tail, MBcircularlist_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBcircularlist * circularlist = MBcircularlist_create();
	CuAssertPtrNotNull(tc, circularlist);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_circularlist_add_remove(circularlist, addfns[a], removefns[r], tc);
		}
	}
	MBcircularlist_delete(circularlist);
}

CuSuite* circularlist_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_circularlist);
	return suite;
}
