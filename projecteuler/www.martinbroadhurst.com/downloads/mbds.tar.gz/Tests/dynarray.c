/*
 *  dynarray.c - demonstrates a dynamic array
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <dynarray.h>

#include "CuTest.h"

void test_dynarray(CuTest *tc)
{
	MBdynarray *array = MBdynarray_create(0); /* No preferred size */
	unsigned int i;
	const char * data;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int pos;

	CuAssertPtrNotNull(tc, array);

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBdynarray_get_count(array), i);
		if (i % 2 == 0) {
			MBdynarray_add_head(array, elements[i]);
		}
		else {
			MBdynarray_add_tail(array, elements[i]);
		}
	}
	CuAssertIntEquals(tc, MBdynarray_get_count(array), n);
		
	MBdynarray_insert(array, 0, "X");								/* Same as MBdynarray_add_head */
	CuAssertStrEquals(tc, MBdynarray_get(array, 0), "X");
	pos = MBdynarray_get_count(array) / 2;
	MBdynarray_insert(array, pos, "Y");	/* Insert in the middle */
	CuAssertStrEquals(tc, MBdynarray_get(array, pos), "Y");
	MBdynarray_insert(array, MBdynarray_get_count(array), "Z");		/* Same as MBdynarray_add_tail */
	CuAssertStrEquals(tc, MBdynarray_get(array, 
				MBdynarray_get_count(array) - 1), "Z");
    pos = MBdynarray_get_count(array) / 2;
	MBdynarray_set(array, pos, "P");
	CuAssertStrEquals(tc, MBdynarray_get(array, pos), "P");
	MBdynarray_set(array, MBdynarray_get_count(array), "Q");			/* Same as MBdynarray_add_tail */
	CuAssertStrEquals(tc, MBdynarray_get(array, 
				MBdynarray_get_count(array) - 1), "Q");

	for (i = 0; i < MBdynarray_get_count(array); i++) {
		data = MBdynarray_get(array, i);
		CuAssertPtrNotNull(tc, data);
	}
	
	for (i = 0; MBdynarray_get_count(array); i++) {
		const unsigned int action = i % 3;
		if (action == 0) {
			data = MBdynarray_remove_head(array);
			CuAssertPtrNotNull(tc, data);
		}
		else if (action == 1) {
			data = MBdynarray_remove_tail(array);
			CuAssertPtrNotNull(tc, data);
		}
		else {
			data = MBdynarray_remove(array, MBdynarray_get_count(array) / 2);
			CuAssertPtrNotNull(tc, data);
		}
	}

	MBdynarray_delete(array);
}

CuSuite* dynarray_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_dynarray);
	return suite;
}
