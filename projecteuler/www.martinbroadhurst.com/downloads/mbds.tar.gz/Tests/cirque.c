/*
 *  cirque.c - demonstrates a circular queue
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <string.h>
#include <stdlib.h>

#include <cirque.h>

#include "CuTest.h"

void test_cirque(CuTest *tc)
{
	MBcirque * cirque;
	char buf[16];
	unsigned int f;
	const unsigned int max = 30;
	const unsigned int size = 10;
	const unsigned int limit = size * 2;
	MBiterator * iterator;
	const char * data;
	unsigned int count = 0;

	cirque = MBcirque_create(size);
	CuAssertPtrNotNull(tc, cirque);
	for (f = 0; f < max; f++) {
		sprintf(buf, "Item %d", f);
		if (f >= limit) {
			/* Start removing at limit to show the cirque doesn't keep growing */
			char *data = MBcirque_remove(cirque);
			CuAssertPtrNotNull(tc, data);
			free(data);
			count--;
		}
		MBcirque_insert(cirque, strdup(buf));
		count++;
		CuAssertIntEquals(tc, MBcirque_get_count(cirque), count);
	}
	CuAssertIntEquals(tc, MBcirque_get_count(cirque), limit);
	iterator = MBcirque_iterator(cirque);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, limit);
	MBiterator_delete(iterator);
	CuAssertIntEquals(tc, cirque->size, limit);
	MBcirque_for_each(cirque, free);
	MBcirque_delete(cirque);
}

CuSuite* cirque_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_cirque);
	return suite;
}
