/*
 *  slist.c - demonstrates a singly-linked list
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <slist.h>

int main(void)
{
	MBslist * list = MBslist_create();
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBsnode * node, * previous;
	unsigned int found;
	MBiterator * iterator;
	const char *data;

	node = NULL;
	for (i = 0; i < n; i++) {
		node = MBslist_insert_after(list, node, elements[i]);
	}

	previous = NULL;
	found = 0;
	node = list->head; 
	while (node != NULL && !found) {
		if (strcmp((const char*)node->data, "C") == 0) {
			MBslist_remove(list, node, previous);	/* Remove "C" */
			found = 1;
		}
		else {
			previous = node;
			node = node->next;
		}
	}

	previous = NULL;
	found = 0;
	node = list->head;
	while (node != NULL && !found) {
		if (strcmp((const char*)node->data, "D") == 0) {
			MBslist_insert_after(list, previous, "C");	/* This is how you insert before a node */
			found = 1;
		}
		else {
			previous = node;
			node = node->next;
		}
	}

	iterator = MBslist_iterator(list);
	printf("List contains:\n");
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
		
	MBslist_delete(list);

	return 0;
}
