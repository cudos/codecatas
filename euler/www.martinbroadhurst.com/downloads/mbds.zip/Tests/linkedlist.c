/*
 *  linkedlist.c - demonstrates a linkedlist
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <linkedlist.h>

#include "CuTest.h"

typedef void (*addfn)(MBlinkedlist*, void*);
typedef void*(*removefn)(MBlinkedlist*);

void test_linkedlist_add_remove(MBlinkedlist *linkedlist, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBlinkedlist_get_count(linkedlist), i);
		addfn(linkedlist, elements[i]);
	}
	CuAssertIntEquals(tc, MBlinkedlist_get_count(linkedlist), n);
	/*MBlinkedlist_for_each(linkedlist, (MBforfn)puts);*/
	it = MBlinkedlist_iterator(linkedlist);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(linkedlist);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBlinkedlist_get_count(linkedlist));
}

void test_linkedlist(CuTest *tc)
{
	addfn addfns[] = { MBlinkedlist_add_tail, MBlinkedlist_add_head };
	removefn removefns[] = { MBlinkedlist_remove_tail, MBlinkedlist_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBlinkedlist * linkedlist = MBlinkedlist_create();
	CuAssertPtrNotNull(tc, linkedlist);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_linkedlist_add_remove(linkedlist, addfns[a], removefns[r], tc);
		}
	}
	MBlinkedlist_delete(linkedlist);
}

CuSuite* linkedlist_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_linkedlist);
	return suite;
}
