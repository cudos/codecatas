/*
 *  accesstree.c - tests a binary tree balanced by access frequency
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <string.h>
#include <stdlib.h>

#include <accesstree.h>
#include <linkedlist.h>

#include "CuTest.h"

void test_accesstree(CuTest *tc)
{
	MBaccesstree * tree;
	MBlinkedlist * list;
	MBlistnode * node;
	const unsigned int n = 100;
	unsigned int i;
	char buf[64];
	MBiterator *iterator;
	char *data;
	unsigned int count;

	tree = MBaccesstree_create((MBcmpfn)strcmp);
	CuAssertPtrNotNull(tc, tree);
	list = MBlinkedlist_create();
	CuAssertPtrNotNull(tc, list);

	i = 0;
    while (i < n) {
		void *copy;
		sprintf(buf, "%d", rand());	
		copy = strdup(buf); 	
		data = MBaccesstree_add(tree, copy);
		if (data == NULL) {
			MBlinkedlist_add_tail(list, copy);
			i++;
			CuAssertIntEquals(tc, 1, MBaccesstree_check_accesses(tree));
		}
		else {
			/* Duplicate entry */
			free(data);
		}
	}
	CuAssertIntEquals(tc, MBaccesstree_get_count(tree), n);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBaccesstree_find(tree, node->data);
		CuAssertIntEquals(tc, 1, MBaccesstree_check_accesses(tree));
		CuAssertPtrNotNull(tc, data);
	}
	CuAssertIntEquals(tc, tree->root->accesses, 1);
	for (i = 0, node = list->head; i < n; i++, node = node->next) {
		unsigned int j;
		for (j = 0; j < i; j++) {
			MBaccesstree_find(tree, node->data);
		}
		CuAssertIntEquals(tc, tree->root->accesses, i + 1);
	}
	CuAssertIntEquals(tc, 1, MBaccesstree_check_accesses(tree));
	iterator = MBaccesstree_iterator(tree);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(iterator);
	for (node = list->tail; node != NULL; node = node->previous) {
		data = MBaccesstree_remove(tree, node->data);
		CuAssertPtrNotNull(tc, data);
		free(data);
		count--;
		CuAssertIntEquals(tc, MBaccesstree_get_count(tree), count);
		CuAssertIntEquals(tc, 1, MBaccesstree_check_accesses(tree));
	}
	
	MBlinkedlist_delete(list);
	MBaccesstree_delete(tree);
}

CuSuite* accesstree_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_accesstree);
	return suite;
}
