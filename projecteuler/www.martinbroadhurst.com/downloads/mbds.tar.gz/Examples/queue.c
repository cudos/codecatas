/*
 *  queue.c - demonstrates a queue
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <queue.h>

int main(void)
{
	MBqueue *queue;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBiterator *iterator;
	const char *data;

	queue = MBqueue_create();
	for (i = 0; i < n; i++) {
		printf("Adding %s\n", elements[i]);
		MBqueue_add(queue, elements[i]);
	}
	printf("Queue contains:\n");
	/*MBqueue_for_each(queue, (MBforfn)puts);*/
	iterator = MBqueue_iterator(queue);
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);

	for (i = 0; i < n; i++) {
		const char *data;
		printf("About to remove %s\n", (const char *)MBqueue_peek(queue)); 
		data = MBqueue_remove(queue);
		printf("Removed %s\n", data);
	}
	MBqueue_delete(queue);

	return 0;
}
