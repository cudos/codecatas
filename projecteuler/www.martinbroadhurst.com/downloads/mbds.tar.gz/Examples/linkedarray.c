#include <stdio.h>
#include <string.h>

#include <linkedarray.h>

int main(void)
{
	MBlinkedarray * list = MBlinkedarray_create();
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	unsigned int node;
	unsigned int found = 0;
	unsigned int removed = 0;
	MBiterator *iterator;
	const char *data;

	for (i = 0; i < n; i++) {
		MBlinkedarray_add_tail(list, elements[i]);
	}

	for (node = MBlinkedarray_get_head(list); node != LINKEDARRAY_NIL && !found; node = MBlinkedarray_get_next(list, node)) {
		if (strcmp((const char*)MBlinkedarray_get_data(list, node), "C") == 0) {
			MBlinkedarray_insert_before(list, node, "X");
			MBlinkedarray_insert_after(list, node, "Y");
			found = 1;
		}
	}
	for (node = MBlinkedarray_get_head(list); node != LINKEDARRAY_NIL && !removed; node = MBlinkedarray_get_next(list, node)) {
		if (strcmp((const char*)MBlinkedarray_get_data(list, node), "D") == 0) {
			MBlinkedarray_remove_node(list, node);
			removed = 1;
		}
	}
	puts("Forwards:");
	for (node = MBlinkedarray_get_head(list); node != LINKEDARRAY_NIL; node = MBlinkedarray_get_next(list, node)) {
		printf("%s\n", (const char*)MBlinkedarray_get_data(list, node));
	}
	puts("Backwards:");
	for (node = MBlinkedarray_get_tail(list); node != LINKEDARRAY_NIL; node = MBlinkedarray_get_previous(list, node)) {
		printf("%s\n", (const char*)MBlinkedarray_get_data(list, node));
	}
	puts("Using iterator:");
	iterator = MBlinkedarray_iterator(list);
	while ((data = MBiterator_get(iterator))) {
		puts(data);
	}
	MBiterator_delete(iterator);
	puts("Unordered:");
	MBlinkedarray_for_each_unordered(list, (MBforfn)puts);
	
	MBlinkedarray_delete(list);

	return 0;
}
