/*
 *  example.c - an example graph program
 *  Copyright (C) 2010 Martin Broadhurst
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <graph1.h>

int main(void)
{
    MBgraph1 *graph;
    MBvertex *vertex;
    MBvertex *A, *B, *C, *D, *E;
    MBiterator *vertices, *edges;
    MBedge *edge;

    /* Create a graph */
    graph = MBgraph1_create();

    /* Add vertices */
    A = MBgraph1_add(graph, "A", NULL);
    B = MBgraph1_add(graph, "B", NULL);
    C = MBgraph1_add(graph, "C", NULL);
    D = MBgraph1_add(graph, "D", NULL);
    E = MBgraph1_add(graph, "E", NULL);

    /* Add edges */
    MBgraph1_add_edge(graph, A, B);
    MBgraph1_add_edge(graph, A, D);
    MBgraph1_add_edge(graph, B, C);
    MBgraph1_add_edge(graph, C, B);
    MBgraph1_add_edge(graph, D, A);
    MBgraph1_add_edge(graph, D, C);
    MBgraph1_add_edge(graph, D, E);

    /* Display */
    printf("Vertices (%d) and their neighbours:\n\n", MBgraph1_get_vertex_count(graph));
    vertices = MBgraph1_get_vertices(graph);
    while ((vertex = MBiterator_get(vertices))) {
        MBiterator *neighbours;
        MBvertex *neighbour;
        unsigned int n = 0;
        printf("%s (%d): ", MBvertex_get_name(vertex), MBgraph1_get_neighbour_count(graph, vertex));
        neighbours = MBgraph1_get_neighbours(graph, vertex);
        while ((neighbour = MBiterator_get(neighbours))) {
            printf("%s", MBvertex_get_name(neighbour));
            if (n < MBgraph1_get_neighbour_count(graph, vertex) - 1) {
                fputs(", ", stdout);
            }
            n++;
        }
        putchar('\n');
        MBiterator_delete(neighbours);
    }
    putchar('\n');
    MBiterator_delete(vertices);
    printf("Edges (%d):\n\n", MBgraph1_get_edge_count(graph));
    edges = MBgraph1_get_edges(graph);
    while ((edge = MBiterator_get(edges))) {
        printf("<%s, %s>\n", MBvertex_get_name(MBedge_get_from(edge)), MBvertex_get_name(MBedge_get_to(edge)));
    }
    putchar('\n');
    MBiterator_delete(edges);

    /* Delete */
    MBgraph1_delete(graph);

    return 0;
}

