/*
 *  binarytree.c - demonstrates an unbalanced binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <binarytree.h>

int main(void)
{
	MBbinarytree * tree;
	char * elements[] = {"D", "B", "C", "A", "F", "G", "E"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int e;
	MBiterator *iterator;
	char *data;

	tree = MBbinarytree_create((MBcmpfn)strcmp);

	for (e = 0; e < n; e++) {
		MBbinarytree_add(tree, elements[e]);
	}
	/*MBbinarytree_for_each(tree, (MBforfn)puts);*/
	printf("Size is %d\n", MBbinarytree_get_count(tree));
	for (e = 0; e < n; e++) {
		data = MBbinarytree_find(tree, elements[e]);
		if (data) {
			printf("Found %s\n", data);
		}
		else {
			printf("Couldn't find %s\n", (const char*)elements[e]);
		}
	}
	iterator = MBbinarytree_iterator(tree);
	printf("Tree contains:\n");
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
	for (e = 0; e < n; e++) {
		printf("Removing %s\n", elements[e]);
		data = MBbinarytree_remove(tree, elements[e]);
		if (data) {
			printf("%s successfully removed\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[e]);
		}
		printf("Size is now %d\n", MBbinarytree_get_count(tree));
	}
	
	MBbinarytree_delete(tree);

	return 0;
}
