/*
 *  stack.c - demonstrates a stack
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <stack.h>

int main(void)
{
	MBstack *stack;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBiterator *iterator;
	const char *data;

	stack = MBstack_create();
	for (i = 0; i < n; i++) {
		printf("Pushing %s\n", elements[i]);
		MBstack_push(stack, elements[i]);
	}
	printf("Stack contains:\n");
	/*MBstack_for_each(stack, (MBforfn)puts);*/
	iterator = MBstack_iterator(stack);
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);

	for (i = 0; i < n; i++) {
		const char *data;
		printf("About to remove %s\n", (const char *)MBstack_peek(stack)); 
		data = MBstack_pop(stack);
		printf("Removed %s\n", data);
	}
	MBstack_delete(stack);

	return 0;
}
