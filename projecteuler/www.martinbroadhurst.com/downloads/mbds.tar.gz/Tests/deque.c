/*
 *  deque.c - demonstrates a deque
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <deque.h>

#include "CuTest.h"

typedef void (*addfn)(MBdeque*, void*);
typedef void*(*removefn)(MBdeque*);

void test_deque_add_remove(MBdeque *deque, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBdeque_get_count(deque), i);
		addfn(deque, elements[i]);
	}
	CuAssertIntEquals(tc, MBdeque_get_count(deque), n);
	/*MBdeque_for_each(deque, (MBforfn)puts);*/
	it = MBdeque_iterator(deque);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(deque);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBdeque_get_count(deque));
}

void test_deque(CuTest *tc)
{
	addfn addfns[] = { MBdeque_push_back, MBdeque_push_front };
	removefn removefns[] = { MBdeque_pop_back, MBdeque_pop_front };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBdeque * deque = MBdeque_create();
	CuAssertPtrNotNull(tc, deque);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_deque_add_remove(deque, addfns[a], removefns[r], tc);
		}
	}
	MBdeque_delete(deque);
}

CuSuite* deque_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_deque);
	return suite;
}
