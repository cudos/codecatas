/*
 *  accesstree.c - demonstrates an unbalanced binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <accesstree.h>

int main(void)
{
	MBaccesstree * tree;
	char * elements[] = {"D", "B", "C", "F", "E", "G", "A"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	const char * data;
	MBiterator *iterator;

	tree = MBaccesstree_create((MBcmpfn)strcmp);

    for (i = 0; i < n; i++) {
		MBaccesstree_add(tree, elements[i]);
	}
	MBaccesstree_for_each(tree, (MBforfn)puts);
	printf("Size is %d\n", MBaccesstree_get_count(tree));
	for (i = 0; i < n; i++) {
		data = MBaccesstree_find(tree, elements[i]);
		if (data) {
			printf("Found %s\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[i]);
		}
		printf("Index is %d\n", MBaccesstree_find_index(tree, elements[i]));
	}
	printf("%d\n", tree->root->accesses);
	iterator = MBaccesstree_iterator(tree);
	printf("Tree contains:\n");
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
	for (i = 0; i < n; i++) {
		printf("Removing %s\n", elements[i]);
		data = MBaccesstree_remove(tree, elements[i]);
		if (data) {
			printf("%s successfully removed\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[i]);
		}
		printf("Size is now %d\n", MBaccesstree_get_count(tree));
	}
	
	MBaccesstree_delete(tree);

	return 0;
}
