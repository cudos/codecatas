#include <stdio.h>

#include "CuTest.h"
    
CuSuite* binarytree_GetSuite();
CuSuite* cirque_GetSuite();
CuSuite* deque_GetSuite();
CuSuite* dynarray_GetSuite();
CuSuite* hashtable_GetSuite();
CuSuite* linkedlist_GetSuite();
CuSuite* queue_GetSuite();
CuSuite* slist_GetSuite();
CuSuite* stack_GetSuite();
CuSuite* randomtree_GetSuite();
CuSuite* toptree_GetSuite();
CuSuite* accesstree_GetSuite();
CuSuite* circularlist_GetSuite();
CuSuite* linkedarray_GetSuite();
CuSuite* centarray_GetSuite();
CuSuite* recyclelist_GetSuite();
CuSuite* sflist_GetSuite();

void RunAllTests(void) {
	CuString *output = CuStringNew();
	CuSuite* suite = CuSuiteNew();
	
	CuSuiteAddSuite(suite, binarytree_GetSuite());
	CuSuiteAddSuite(suite, cirque_GetSuite());
	CuSuiteAddSuite(suite, deque_GetSuite());
	CuSuiteAddSuite(suite, dynarray_GetSuite());
	CuSuiteAddSuite(suite, hashtable_GetSuite());
	CuSuiteAddSuite(suite, linkedlist_GetSuite());
	CuSuiteAddSuite(suite, queue_GetSuite());
	CuSuiteAddSuite(suite, slist_GetSuite());
	CuSuiteAddSuite(suite, stack_GetSuite());
	CuSuiteAddSuite(suite, randomtree_GetSuite());
	CuSuiteAddSuite(suite, toptree_GetSuite());
	CuSuiteAddSuite(suite, accesstree_GetSuite());
	CuSuiteAddSuite(suite, circularlist_GetSuite());
	CuSuiteAddSuite(suite, linkedarray_GetSuite());
	CuSuiteAddSuite(suite, centarray_GetSuite());
	CuSuiteAddSuite(suite, recyclelist_GetSuite());
	CuSuiteAddSuite(suite, sflist_GetSuite());

	CuSuiteRun(suite);
	CuSuiteSummary(suite, output);
	CuSuiteDetails(suite, output);
	printf("%s\n", output->buffer);
}

int main(void) {
	RunAllTests();
	return 0;
}
