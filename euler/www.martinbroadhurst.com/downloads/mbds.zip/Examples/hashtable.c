/*
 *  hashtable.c - demonstrates a hash table
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <hashtable.h>

/* The SDBM hash */
unsigned int myhashfunc(const char * str)
{
	unsigned int hash = 0;
	int c;

	while ((c = *str++)) {
		hash = c + (hash << 6) + (hash << 16) - hash;
	}

	return hash;
}

int main(void)
{
	MBhashtable * table;
	const char * result;
	unsigned int e;
	char * elements[] = {"A", "B", "C", "D", "E", "F", "G"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator * iterator;

	table = MBhashtable_create(7, (MBhashfn)myhashfunc, (MBcmpfn)strcmp);
	for (e = 0; e < n; e++) {
		MBhashtable_add(table, elements[e]);
	}
	/*MBhashtable_for_each(table, (MBforfn)puts);*/
	iterator = MBhashtable_iterator(table);
	while ((result = MBiterator_get(iterator))) {
		printf("%s\n", result);
	}
	MBiterator_delete(iterator);
	for (e = 0; e < n; e++) {
		result = MBhashtable_find(table, elements[e]);
		if (result) {
			printf("Found: %s\n", result);
		}
		else {
			printf("Couldn't find %s\n", elements[e]);
		}
	}
	printf("The load factor is %.2f\n", MBhashtable_get_load_factor(table));
	for (e = 0; e < n; e++) {
		result = MBhashtable_remove(table, elements[e]);
		if (result) {
			printf("Removed: %s\n", result);
		}
		else {
			printf("Couldn't remove %s\n", elements[e]);
		}
	}
	MBhashtable_delete(table);

	return 0;
}
