/*
 *  centarray.c - demonstrates a dynamic array
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <centarray.h>

int main(void)
{
	MBcentarray *array = MBcentarray_create();
	unsigned int i;
	void * data;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);

	for (i = 0; i < n; i++) {
		if (i % 2 == 0) {
			MBcentarray_add_head(array, elements[i]);
		}
		else {
			MBcentarray_add_tail(array, elements[i]);
		}
	}
		
	MBcentarray_insert(array, 0, "X");								/* Same as MBcentarray_add_head */
	MBcentarray_insert(array, MBcentarray_get_count(array) / 2, "Y");	/* Insert in the middle */
	MBcentarray_insert(array, MBcentarray_get_count(array), "Z");		/* Same as MBcentarray_add_tail */

	MBcentarray_set(array, MBcentarray_get_count(array) / 2, "P");
	MBcentarray_set(array, MBcentarray_get_count(array), "Q");			/* Same as MBcentarray_add_tail */

	for (i = 0; i < MBcentarray_get_count(array); i++) {
		printf("%d: %s\n", i, (const char*)MBcentarray_get(array, i));
	}
	putchar('\n');
	
	for (i = 0; MBcentarray_get_count(array); i++) {
		const unsigned int action = i % 3;
		if (action == 0) {
			data = MBcentarray_remove_head(array);
		}
		else if (action == 1) {
			data = MBcentarray_remove_tail(array);
		}
		else {
			data = MBcentarray_remove(array, MBcentarray_get_count(array) / 2);
		}
		printf("Removed: %s\n", (const char*)data);
	}

	MBcentarray_delete(array);

	return 0;
}
