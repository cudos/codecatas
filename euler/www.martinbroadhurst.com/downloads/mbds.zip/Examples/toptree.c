/*
 *  toptree.c - demonstrates a move-to-top binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <toptree.h>

int main(void)
{
	MBtoptree * tree;
	char * elements[] = {"D", "B", "C", "A", "F", "G", "E"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int e;
	MBiterator *iterator;
	char *data;

	tree = MBtoptree_create((MBcmpfn)strcmp);

	for (e = 0; e < n; e++) {
		MBtoptree_add(tree, elements[e]);
	}
	/*MBtoptree_for_each(tree, (MBforfn)puts);*/
	printf("Size is %d\n", MBtoptree_get_count(tree));
	for (e = 0; e < n; e++) {
		data = MBtoptree_find(tree, elements[e]);
		if (data) {
			printf("Found %s\n", data);
		}
		else {
			printf("Couldn't find %s\n", (const char*)elements[e]);
		}
	}
	iterator = MBtoptree_iterator(tree);
	printf("Tree contains:\n");
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", data);
	}
	MBiterator_delete(iterator);
	for (e = 0; e < n; e++) {
		printf("Removing %s\n", elements[e]);
		data = MBtoptree_remove(tree, elements[e]);
		if (data) {
			printf("%s successfully removed\n", data);
		}
		else {
			printf("Couldn't find %s\n", elements[e]);
		}
		printf("Size is now %d\n", MBtoptree_get_count(tree));
	}
	
	MBtoptree_delete(tree);

	return 0;
}
