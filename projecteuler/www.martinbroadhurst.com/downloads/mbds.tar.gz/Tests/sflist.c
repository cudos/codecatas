/*
 *  sflist.c - demonstrates a sflist
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <sflist.h>

#include "CuTest.h"

typedef void (*addfn)(MBsflist*, void*);
typedef void*(*removefn)(MBsflist*);

void test_sflist_add_remove(MBsflist *sflist, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBsflist_get_count(sflist), i);
		addfn(sflist, elements[i]);
	}
	CuAssertIntEquals(tc, MBsflist_get_count(sflist), n);
	/*MBsflist_for_each(sflist, (MBforfn)puts);*/
	it = MBsflist_iterator(sflist);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(sflist);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBsflist_get_count(sflist));
}

void test_sflist(CuTest *tc)
{
	addfn addfns[] = { MBsflist_add_tail, MBsflist_add_head };
	removefn removefns[] = { MBsflist_remove_tail, MBsflist_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBsflist * sflist = MBsflist_create();
	CuAssertPtrNotNull(tc, sflist);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_sflist_add_remove(sflist, addfns[a], removefns[r], tc);
		}
	}
	MBsflist_delete(sflist);
}

CuSuite* sflist_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_sflist);
	return suite;
}
