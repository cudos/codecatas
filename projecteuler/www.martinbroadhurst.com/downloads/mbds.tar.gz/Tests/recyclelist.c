/*
 *  recyclelist.c - demonstrates a recyclelist
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */


#include <recyclelist.h>

#include "CuTest.h"

typedef void (*addfn)(MBrecyclelist*, void*);
typedef void*(*removefn)(MBrecyclelist*);

void test_recyclelist_add_remove(MBrecyclelist *recyclelist, addfn addfn, removefn removefn, CuTest *tc)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;
	unsigned int count;

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBrecyclelist_get_count(recyclelist), i);
		addfn(recyclelist, elements[i]);
	}
	CuAssertIntEquals(tc, MBrecyclelist_get_count(recyclelist), n);
	/*MBrecyclelist_for_each(recyclelist, (MBforfn)puts);*/
	it = MBrecyclelist_iterator(recyclelist);
	CuAssertPtrNotNull(tc, it);
	count = 0;
	while ((data = MBiterator_get(it))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(it);

	for (i = 0; i < n; i++) {
		data = removefn(recyclelist);
		CuAssertPtrNotNull(tc, data);
		count--;
	}
	CuAssertIntEquals(tc, count, MBrecyclelist_get_count(recyclelist));
}

void test_recyclelist(CuTest *tc)
{
	addfn addfns[] = { MBrecyclelist_add_tail, MBrecyclelist_add_head };
	removefn removefns[] = { MBrecyclelist_remove_tail, MBrecyclelist_remove_head };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	unsigned int a, r;
	MBrecyclelist * recyclelist = MBrecyclelist_create();
	CuAssertPtrNotNull(tc, recyclelist);
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test_recyclelist_add_remove(recyclelist, addfns[a], removefns[r], tc);
		}
	}
	MBrecyclelist_delete(recyclelist);
}

CuSuite* recyclelist_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_recyclelist);
	return suite;
}
