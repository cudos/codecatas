/*
 *  dynarray.c - demonstrates a dynamic array
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <dynarray.h>

int main(void)
{
	MBdynarray *array = MBdynarray_create(0); /* No preferred size */
	unsigned int i;
	void * data;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);

	for (i = 0; i < n; i++) {
		if (i % 2 == 0) {
			MBdynarray_add_head(array, elements[i]);
		}
		else {
			MBdynarray_add_tail(array, elements[i]);
		}
	}
		
	MBdynarray_insert(array, 0, "X");								/* Same as MBdynarray_add_head */
	MBdynarray_insert(array, MBdynarray_get_count(array) / 2, "Y");	/* Insert in the middle */
	MBdynarray_insert(array, MBdynarray_get_count(array), "Z");		/* Same as MBdynarray_add_tail */

	MBdynarray_set(array, MBdynarray_get_count(array) / 2, "P");
	MBdynarray_set(array, MBdynarray_get_count(array), "Q");			/* Same as MBdynarray_add_tail */

	for (i = 0; i < MBdynarray_get_count(array); i++) {
		printf("%d: %s\n", i, (const char*)MBdynarray_get(array, i));
	}
	putchar('\n');
	
	for (i = 0; MBdynarray_get_count(array); i++) {
		const unsigned int action = i % 3;
		if (action == 0) {
			data = MBdynarray_remove_head(array);
		}
		else if (action == 1) {
			data = MBdynarray_remove_tail(array);
		}
		else {
			data = MBdynarray_remove(array, MBdynarray_get_count(array) / 2);
		}
		printf("Removed: %s\n", (const char*)data);
	}

	MBdynarray_delete(array);

	return 0;
}
