/*
 *  stack.c - demonstrates a stack
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stack.h>

#include "CuTest.h"

void test_stack(CuTest *tc)
{
	MBstack *stack;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBiterator *iterator;
	const char *data;
	unsigned int count;

	stack = MBstack_create();
	CuAssertPtrNotNull(tc, stack);
	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, i, MBstack_get_count(stack));
		MBstack_push(stack, elements[i]);
	}
	CuAssertIntEquals(tc, n, MBstack_get_count(stack));
	/*MBstack_for_each(stack, (MBforfn)puts);*/
	iterator = MBstack_iterator(stack);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		CuAssertStrEquals(tc, elements[(n - count) - 1], data);
		count++;
	}
	CuAssertIntEquals(tc, n, count);
	MBiterator_delete(iterator);

	for (i = 0; i < n; i++) {
		data = MBstack_peek(stack);
		CuAssertStrEquals(tc, elements[(n - i) - 1], data);
		data = MBstack_pop(stack);
		CuAssertStrEquals(tc, elements[(n - i) - 1], data);
		CuAssertIntEquals(tc, n - (i + 1), MBstack_get_count(stack)); 
	}
	CuAssertPtrNull(tc, MBstack_peek(stack));
	MBstack_delete(stack);
}

CuSuite* stack_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_stack);
	return suite;
}
