/*
 *  linkedlist.c - demonstrates a doubly-linked list
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>
#include <string.h>

#include <linkedlist.h>

int main(void)
{
	MBlinkedlist * list = MBlinkedlist_create();
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int i;
	MBlistnode * node;
	unsigned int found = 0;
	MBiterator * iterator;
	const void * data;

	for (i = 0; i < n; i++) {
		MBlinkedlist_add_tail(list, elements[i]);
	}

	for (node = list->head; node != NULL && !found; node = node->next) {
		if (strcmp((const char*)node->data, "C") == 0) {
			MBlinkedlist_insert_before(list, node, "X");
			MBlinkedlist_insert_after(list, node, "Y");
			found = 1;
		}
	}

	iterator = MBlinkedlist_iterator(list);
	while ((data = MBiterator_get(iterator))) {
		printf("%s\n", (const char*)data);
	}
	MBiterator_delete(iterator);
	putchar('\n');

	for (node = list->tail; node != NULL; node = node->previous) {
		printf("%s\n", (const char*)node->data);
	}
	
	MBlinkedlist_delete(list);

	return 0;
}
