/*
 *  centarray.c - tests a dynamic array
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <centarray.h>

#include "CuTest.h"

void test_centarray(CuTest *tc)
{
	MBcentarray *array = MBcentarray_create();
	unsigned int i;
	const char * data;
	char *elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	unsigned int pos;

	CuAssertPtrNotNull(tc, array);

	for (i = 0; i < n; i++) {
		CuAssertIntEquals(tc, MBcentarray_get_count(array), i);
		if (i % 2 == 0) {
			MBcentarray_add_head(array, elements[i]);
		}
		else {
			MBcentarray_add_tail(array, elements[i]);
		}
	}
	CuAssertIntEquals(tc, MBcentarray_get_count(array), n);
		
	MBcentarray_insert(array, 0, "X");								/* Same as MBcentarray_add_head */
	CuAssertStrEquals(tc, MBcentarray_get(array, 0), "X");
	pos = MBcentarray_get_count(array) / 2;
	MBcentarray_insert(array, pos, "Y");	/* Insert in the middle */
	CuAssertStrEquals(tc, MBcentarray_get(array, pos), "Y");
	MBcentarray_insert(array, MBcentarray_get_count(array), "Z");		/* Same as MBcentarray_add_tail */
	CuAssertStrEquals(tc, MBcentarray_get(array, 
				MBcentarray_get_count(array) - 1), "Z");
    pos = MBcentarray_get_count(array) / 2;
	MBcentarray_set(array, pos, "P");
	CuAssertStrEquals(tc, MBcentarray_get(array, pos), "P");
	MBcentarray_set(array, MBcentarray_get_count(array), "Q");			/* Same as MBcentarray_add_tail */
	CuAssertStrEquals(tc, MBcentarray_get(array, 
				MBcentarray_get_count(array) - 1), "Q");

	for (i = 0; i < MBcentarray_get_count(array); i++) {
		data = MBcentarray_get(array, i);
		CuAssertPtrNotNull(tc, data);
	}
	
	for (i = 0; MBcentarray_get_count(array); i++) {
		const unsigned int action = i % 3;
		if (action == 0) {
			data = MBcentarray_remove_head(array);
			CuAssertPtrNotNull(tc, data);
		}
		else if (action == 1) {
			data = MBcentarray_remove_tail(array);
			CuAssertPtrNotNull(tc, data);
		}
		else {
			data = MBcentarray_remove(array, MBcentarray_get_count(array) / 2);
			CuAssertPtrNotNull(tc, data);
		}
	}

	MBcentarray_delete(array);
}

CuSuite* centarray_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_centarray);
	return suite;
}
