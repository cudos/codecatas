#include <stdio.h>
#include <string.h>

#include <circularlist.h>

int main(void)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBcircularlist * list;
	unsigned int i;
	MBcnode * node;
	unsigned int removed = 0, added = 0;
	MBiterator *iterator;
	const char *data;

	list = MBcircularlist_create();
	if (list) {
		/* Populate the list */
		for (i = 0; i < n; i++) {
			MBcircularlist_add_tail(list, elements[i]);
		}

		/* Remove "C" */
		node = list->head;
		do {
			if (strcmp((const char*)node->data, "A") == 0) {
				MBcircularlist_remove_node(list, node);
				removed = 1;
			}
			else {
				node = node->next;
			}
		} while (node != list->head && !removed);

		/* Add "X" and "Y" either side of "D" */
		node = list->head;
		do {
			if (strcmp((const char*)node->data, "D") == 0) {
				MBcircularlist_insert_before(list, node, "X");
				MBcircularlist_insert_after(list, node, "Y");
				added = 1;
			}
			else {
				node = node->next;
			}
		} while (node != list->head && !added);

		/* Print */
		printf("Count is %d\n", MBcircularlist_get_count(list));
		/*MBcircularlist_for_each(list, (MBforfn)puts);*/
		iterator = MBcircularlist_iterator(list);
		while ((data = MBiterator_get(iterator))) {
			printf("%s\n", data);
		}
		MBiterator_delete(iterator);

		MBcircularlist_delete(list);
	}
	return 0;
}
