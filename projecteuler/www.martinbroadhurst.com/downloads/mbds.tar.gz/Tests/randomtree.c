/*
 *  randomtree.c - tests a randomised binary tree
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <string.h>
#include <stdlib.h>

#include <randomtree.h>
#include <linkedlist.h>

#include "CuTest.h"

void test_randomtree(CuTest *tc)
{
	MBrandomtree * tree;
	MBlinkedlist * list;
	MBlistnode * node;
	const unsigned int n = 1000;
	unsigned int i;
	char buf[64];
	MBiterator *iterator;
	char *data;
	unsigned int count;

	tree = MBrandomtree_create((MBcmpfn)strcmp);
	CuAssertPtrNotNull(tc, tree);
	list = MBlinkedlist_create();
	CuAssertPtrNotNull(tc, list);

	i = 0;
    while (i < n) {
		void *copy;
		sprintf(buf, "%d", rand());	
		copy = strdup(buf); 	
		data = MBrandomtree_add(tree, copy);
		if (data == NULL) {
			MBlinkedlist_add_tail(list, copy);
			i++;
			CuAssertIntEquals(tc, 1, MBrandomtree_check_keys(tree));
		}
		else {
			/* Duplicate entry */
			free(data);
		}
	}
	CuAssertIntEquals(tc, MBrandomtree_get_count(tree), n);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBrandomtree_find(tree, node->data);
		CuAssertPtrNotNull(tc, data);
	}
	iterator = MBrandomtree_iterator(tree);
	CuAssertPtrNotNull(tc, iterator);
	count = 0;
	while ((data = MBiterator_get(iterator))) {
		CuAssertPtrNotNull(tc, data);
		count++;
	}
	CuAssertIntEquals(tc, count, n);
	MBiterator_delete(iterator);
	for (node = list->head; node != NULL; node = node->next) {
		data = MBrandomtree_remove(tree, node->data);
		CuAssertPtrNotNull(tc, data);
		free(data);
		count--;
		CuAssertIntEquals(tc, MBrandomtree_get_count(tree), count);
		CuAssertIntEquals(tc, 1, MBrandomtree_check_keys(tree));
	}
	
	MBlinkedlist_delete(list);
	MBrandomtree_delete(tree);
}

CuSuite* randomtree_GetSuite() {
	CuSuite* suite = CuSuiteNew();
	SUITE_ADD_TEST(suite, test_randomtree);
	return suite;
}
