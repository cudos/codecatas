/*
 *  deque.c - demonstrates a deque
 *  Copyright (C) 2010 Martin Broadhurst 
 *  www.martinbroadhurst.com
 */

#include <stdio.h>

#include <deque.h>

typedef void (*addfn)(MBdeque*, void*);
typedef void*(*removefn)(MBdeque*);

void test(MBdeque *deque, addfn addfn, removefn removefn)
{
	char * elements[] = {"A", "B", "C", "D", "E", "F"};
	unsigned int i;
	const unsigned int n = sizeof(elements) / sizeof(const char*);
	MBiterator *it;
	void *data;

	for (i = 0; i < n; i++) {
		addfn(deque, elements[i]);
	}
	printf("front is %s, back is %s\n", (const char *)MBdeque_peek_front(deque), (const char *)MBdeque_peek_back(deque));

	/*MBdeque_for_each(deque, (MBforfn)puts);*/
	it = MBdeque_iterator(deque);
	while ((data = MBiterator_get(it))) {
		printf("%s\n", (const char*)data);
	}
	MBiterator_delete(it);
	putchar('\n');

	for (i = 0; i < n; i++) {
		data = removefn(deque);
		printf("%s\n", data ? (const char*)data : "NULL");
	}
	putchar('\n');
}

int main(void)
{
	addfn addfns[] = { MBdeque_push_back, MBdeque_push_front };
	removefn removefns[] = { MBdeque_pop_back, MBdeque_pop_front };
	const unsigned int nfns = sizeof(addfns) / sizeof(addfn);
	MBdeque * deque = MBdeque_create();
	unsigned int a, r;
	for (a = 0; a < nfns; a++) {
		for (r = 0; r < nfns; r++) {
			test(deque, addfns[a], removefns[r]);
		}
	}
	MBdeque_delete(deque);

	return 0;
}
